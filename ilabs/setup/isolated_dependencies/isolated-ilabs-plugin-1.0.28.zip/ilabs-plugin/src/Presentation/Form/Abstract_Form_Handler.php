<?php

namespace Isolated\BlueMedia\Ilabs\Ilabs_Plugin\Presentation\Form;

abstract class Abstract_Form_Handler
{
}
