<?php

namespace Isolated\BlueMedia\Ilabs\Ilabs_Plugin\Presentation\Form;

class Form_Handler_Request
{
}
