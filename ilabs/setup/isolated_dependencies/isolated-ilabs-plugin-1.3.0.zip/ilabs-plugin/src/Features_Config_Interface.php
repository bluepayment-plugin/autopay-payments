<?php

namespace Isolated\BlueMedia\Ilabs\Ilabs_Plugin;

interface Features_Config_Interface
{
    public function get_config() : array;
}
